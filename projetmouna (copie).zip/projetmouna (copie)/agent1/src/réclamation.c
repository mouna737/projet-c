#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"réclamation.h"
int tableau_reclamation(reclamation tab[])
{
int n=0;
FILE *f=fopen("/home/mouna/Bureau/projetmouna/client1/src/users.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s",&tab[n].id)!=EOF)
{n++;}
fclose(f);
}
return n;
}
