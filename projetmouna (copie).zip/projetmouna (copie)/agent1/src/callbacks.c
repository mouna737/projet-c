#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "afficher.h"
#include "ajouter.h"


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*addWindow;
addWindow=lookup_widget(objet,"reponseagent");
addWindow=create_reponseagent();
gtk_widget_show(addWindow);
}


void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*espaceagent,*reponseagent;
espaceagent=lookup_widget(objet,"espaceagent");
espaceagent=create_espaceagent();
reponseagent=lookup_widget(objet,"reponseagent");
gtk_widget_destroy(reponseagent);
gtk_widget_show(espaceagent);
}




void
on_button1_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data)
{

GtkWidget*espaceagent;
GtkWidget*afficherreponse;
GtkWidget*treeview1;
espaceagent=lookup_widget(objet,"espaceagent");
gtk_widget_destroy(afficherreponse);
afficherreponse=lookup_widget(objet,"afficherreponse");
afficherreponse=create_afficherreponse();
gtk_widget_show(afficherreponse);
treeview1=lookup_widget(afficherreponse,"treeview1");


afficher_reclamation(treeview1);
}


void
on_confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
reponse r;
GtkWidget *input1,*input2;




input1=lookup_widget(objet,"idclient");
input2=lookup_widget(objet,"reponse");


strcpy(r.id,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(r.rep,gtk_entry_get_text(GTK_ENTRY(input2)));
//printf("%s %s\n",r.id,r.rep);
ajouter_reponse(r);
GtkWidget *output;
output=lookup_widget(objet,"messagem");
gtk_label_set_text(GTK_LABEL(output),"envoyé!");
}


void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*espaceagent,*afficherreponse;
espaceagent=lookup_widget(objet,"espaceagent");
espaceagent=create_espaceagent();
afficherreponse=lookup_widget(objet,"afficherreponse");
gtk_widget_destroy(afficherreponse);
gtk_widget_show(espaceagent);
}

