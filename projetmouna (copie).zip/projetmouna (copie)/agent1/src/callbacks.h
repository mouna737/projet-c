#include <gtk/gtk.h>


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);
