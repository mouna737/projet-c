typedef struct 
{
char id[30];

char rep[100];
}reponse ;
void ajouter_reponse(reponse r);
