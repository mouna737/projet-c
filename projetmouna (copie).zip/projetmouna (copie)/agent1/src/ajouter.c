#include<stdio.h>
#include<string.h>
#include"ajouter.h"
void ajouter_reponse(reponse r)
{
FILE*f;
f=fopen("/home/mouna/Bureau/projetmouna/client1/src/mailagent.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s\n",r.id,r.rep);
fclose(f);
}
}
