typedef struct
{
char id;
char date;
char recl;
}reclamation;
int tableau_reclamation(reclamation tab[50]);
