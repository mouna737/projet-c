#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"réclamation.h"
#include"afficher.h"

void
on_confirmer_clicked                   (GtkWidget      *objet,
                                        gpointer         user_data)
{
reclamation r;
GtkWidget *input1,*input2,*input3;




input1=lookup_widget(objet,"id");
input2=lookup_widget(objet,"date");
input3=lookup_widget(objet,"recl");


strcpy(r.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.date,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(r.recl,gtk_entry_get_text(GTK_ENTRY(input3)));
//printf("%s %s %s\n",r.id,r.date,r.recl);
ajouter_reclamation(r);
GtkWidget *output;
output=lookup_widget(objet,"messagem");
gtk_label_set_text(GTK_LABEL(output),"envoyé!");
}



void
on_annuler_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_mail_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*espaceclient;
GtkWidget*mailagent;
GtkWidget*treeview1;
espaceclient=lookup_widget(objet,"espaceclient");
gtk_widget_destroy(espaceclient);
mailagent=lookup_widget(objet,"mailagent");
mailagent=create_mailagent();
gtk_widget_show(mailagent);
treeview1=lookup_widget(mailagent,"treeview1");


afficher_reponse(treeview1);
}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*espaceclient,*mailagent;
espaceclient=lookup_widget(objet,"espaceclient");
espaceclient=create_espaceclient();
mailagent=lookup_widget(objet,"mailagent");
gtk_widget_destroy(mailagent);
gtk_widget_show(espaceclient);
}

