typedef struct 
{
char id[30];
char date[30];
char recl[100];
}reclamation ;
void ajouter_reclamation(reclamation r);
