#include<gtk/gtk.h>
typedef struct
{
char id[30];

char rep[100];

}reponse;
void afficher_reponse(GtkWidget *liste);
