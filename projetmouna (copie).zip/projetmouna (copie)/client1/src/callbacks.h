#include <gtk/gtk.h>


void
on_confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_annuler_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mail_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);
