#include<stdio.h>
#include<string.h>
#include"réclamation.h"
void ajouter_reclamation(reclamation r)
{
FILE*f;
f=fopen("users.txt","a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s\n",r.id,r.date,r.recl);
fclose(f);
}
else
printf("\n failed");
}
