#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "afficher.h"

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*espaceadmin;
GtkWidget*afficherclient;
GtkWidget*treeview1;
espaceadmin=lookup_widget(objet,"espaceadmin");
gtk_widget_destroy(espaceadmin);
afficherclient=lookup_widget(objet,"afficherclient");
afficherclient=create_afficherclient();
gtk_widget_show(afficherclient);
treeview1=lookup_widget(afficherclient,"treeview1");
afficher_reclamation(treeview1);

}


void
on_s__lectionner_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *treeview2;
GtkWidget *input1;
GtkWidget *output;
GtkWidget *afficherclient;
GtkWidget *reponseadmin;
reclamation r;

char ch[30];

FILE *f,*tmp;
int i=0;
input1=lookup_widget(objet,"modifier");
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(input1)));
output=lookup_widget(objet,"message");
f=fopen("/home/mouna/Bureau/projetmouna/client1/src/users.txt","r");
tmp=fopen("/home/mouna/Bureau/projetmouna/client1/src/tmp.txt","w");
while(fscanf(f,"%s %s %s",r.id,r.date,r.recl)!=EOF)
{
if(strcmp(ch,r.id)==0)
{i++;
fprintf(tmp,"%s %s %s",r.id,r.date,r.recl);
break;
}
}
fclose(f);
fclose(tmp);
if(i!=0)
{
reponseadmin=lookup_widget(objet,"reponseadmin");
reponseadmin=create_reponseadmin();
gtk_widget_show(reponseadmin);
treeview2=lookup_widget(reponseadmin,"treeview2");
afficher2_reclamation(treeview2);
remove("/home/mouna/Bureau/projetmouna/client1/src/tmp.txt");
}
else
{gtk_label_set_text(GTK_LABEL(output),"id introuvable");}
}


void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *output;
char id1[30];
char id[30];
char date[30];
char recl[30];
FILE *f;
FILE *tmp;
input1=lookup_widget(objet,"modifier");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input1)));
output=lookup_widget(objet,"message2");
f=fopen("/home/mouna/Bureau/projetmouna/client1/src/users.txt","r");
tmp=fopen("/home/mouna/Bureau/projetmouna/client1/src/tmp.txt","w");
while(fscanf(f,"%s %s %s",id,date,recl)!=EOF)
{
if(strcmp(id,id1)!=0)
{
fprintf(tmp,"%s %s %s/n",id,date,recl);
}}
fclose(f);
fclose(tmp);
remove("/home/mouna/Bureau/projetmouna/client1/src/users.txt");
rename("/home/mouna/Bureau/projetmouna/client1/src/tmp.txt","/home/mouna/Bureau/projetmouna/client1/src/users.txt");
gtk_label_set_text(GTK_LABEL(output),"reclamation supprimée");

}



void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*espaceadmin,*afficherclient;
espaceadmin=lookup_widget(objet,"espaceadmin");
espaceadmin=create_espaceadmin();
afficherclient=lookup_widget(objet,"afficherclient");
gtk_widget_destroy(afficherclient);
gtk_widget_show(espaceadmin);  
}
                                      





void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget*afficherclient,*reponseadmin;
afficherclient=lookup_widget(objet,"afficherclient");
reponseadmin=create_reponseadmin();
reponseadmin=lookup_widget(objet,"reponseadmin");
gtk_widget_destroy(reponseadmin);
gtk_widget_show(afficherclient);  
}

