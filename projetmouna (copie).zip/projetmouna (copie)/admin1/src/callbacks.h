#include <gtk/gtk.h>


void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_s__lectionner_clicked               (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_retour2_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);
