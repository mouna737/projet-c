#include<gtk/gtk.h>
typedef struct
{
char id[30];
char date[30];
char recl[330];

}reclamation;
void afficher_reclamation(GtkWidget *liste);
