#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"reservation.h"
int verifier_reserver_voiture(reservationvoiture voi)
{
 client c;
 reservationvoiture vo;
int v=0;
FILE*f=fopen("reservationvoiture.txt","r");
if (f!=NULL)
{
while(!v && fscanf(f,"%s %s %d %d %d %d %d %f    %s\n",vo.nom_voi,vo.ville,&vo.dt_res.jour,&vo.dt_res.mois,&vo.dt_res.annee,
&vo.hr_res,&vo.hr_retour,&vo.prix,c.id)!=EOF)
{
if(strcmp(vo.nom_voi,voi.nom_voi)==0)
{
if((vo.dt_res.jour==voi.dt_res.jour)&&(vo.dt_res.mois==voi.dt_res.mois)&&(vo.dt_res.annee==voi.dt_res.annee)&&(vo.hr_res==voi.hr_res))
{
v=1;
}
}
}
}
fclose(f);
return v;
}



  int tableau_voiture_disponible(char voiture[100][50],char ville[50]
,Date dt_res,int hr_res)
{
  int i,nv=0;
  FILE*f=fopen("voiture.txt","r");
  reservationvoiture vo;
  vo.dt_res=dt_res;
  vo.hr_res=hr_res;
  if(f!=NULL)
  {
    while(fscanf(f,"%s %s %f",vo.nom_voi,vo.ville,&vo.prix)!=EOF)
    {
      if(strcmp(vo.ville,ville)==0)
        {
           int v=verifier_reserver_voiture(vo);
            if(!v)
          {
              strcpy(voiture[nv],vo.nom_voi);
            nv++;
          }
       } 
    }      
  }
    fclose(f);
    return nv;
}
void reserver_voiture(reservationvoiture vo,client c)
{
FILE*f=fopen("reservationvoiture.txt","a");
if(f!=NULL)
{
fprintf(f,"%s %s %d %d %d %d %d %f %s\n",vo.nom_voi,vo.ville,vo.dt_res.jour,vo.dt_res.mois,vo.dt_res.annee,
vo.hr_res,vo.hr_retour,vo.prix,c.id);
fclose(f);
}
}
    float calculer_prix_voiture(char voiture[50],char ville[50])
{reservationvoiture vo;
float somme;
float prix;
FILE*f=fopen("voiture.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %f",vo.nom_voi,vo.ville,&vo.prix)!=EOF)
{
if(strcmp(vo.nom_voi,voiture)==0&&(strcmp(vo.ville,ville)==0))
{prix=vo.prix;}
}
}
fclose(f);
somme=prix;
return somme;
}

