#include <gtk/gtk.h>


void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);
