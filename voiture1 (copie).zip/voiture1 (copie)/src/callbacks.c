#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"reservation.h"
#include<string.h>
#include<gtk/gtkclist.h>
#include<gdk/gdkkeysyms.h>


void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *comboboxv;
GtkWidget *combobox1;
GtkWidget *combobox4;
GtkWidget *erreur;
Date dt_res;
int n,i;
char voiture[100][50];
char ville[50];
char message[50];
int hr_res;
reservationvoiture vo;
jour=lookup_widget(objet,"jour");
mois=lookup_widget(objet,"mois");
annee=lookup_widget(objet,"annee");
comboboxv=lookup_widget(objet,"comboboxv");
combobox1=lookup_widget(objet,"combobox1");
combobox4=lookup_widget(objet,"combobox4");
erreur=lookup_widget(objet,"erreur");
dt_res.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
dt_res.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
dt_res.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(ville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxv)));
if(strcmp("9.00h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
 hr_res=1;
else
 hr_res=2;

n=tableau_voiture_disponible(voiture,ville,dt_res,hr_res);


if(n>0)
{
for(i=0;i<n;i++)
{
gtk_combo_box_append_text(GTK_COMBO_BOX(combobox4),_(voiture[i]));
}
}
else if(n==0)
 {
  strcpy(message,"voiture non disponible");
 gtk_label_set_text(GTK_LABEL(erreur),message);
 }
}


void
on_confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *comboboxv;
GtkWidget *combobox1;
GtkWidget *combobox2;
GtkWidget *combobox4;
GtkWidget *label_prix;
GtkWidget *ID;
GtkWidget *sortie;
char voiture[50];
char ville[50];
char message[50],prix[50],id[20];
float prix_voiture;
reservationvoiture vo;
client c;

jour=lookup_widget(objet,"jour");
mois=lookup_widget(objet,"mois");
annee=lookup_widget(objet,"annee");
comboboxv=lookup_widget(objet,"comboboxv");
combobox1=lookup_widget(objet,"combobox1");
combobox2=lookup_widget(objet,"combobox2");
combobox4=lookup_widget(objet,"combobox4");
ID=lookup_widget(objet,"id");
label_prix=lookup_widget(objet,"label_prix");
sortie=lookup_widget(objet,"sortie");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(ID)));
vo.dt_res.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
vo.dt_res.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
vo.dt_res.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(voiture,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox4)));
strcpy(ville,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxv)));
if(strcmp("9.00h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
vo.hr_res=1;
else
vo.hr_res=2;
if(strcmp("9.00h",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)))==0)
vo.hr_retour=1;
else
vo.hr_retour=2;

prix_voiture=calculer_prix_voiture(voiture,ville);
sprintf(prix, "%f",prix_voiture);
gtk_label_set_text(GTK_LABEL(label_prix),prix);
vo.prix=prix_voiture;
strcpy(c.id,id);
strcpy(vo.ville,ville);
strcpy(vo.nom_voi,voiture);
reserver_voiture(vo,c);
gtk_label_set_text(GTK_LABEL(sortie),"reservation reussite");


}
