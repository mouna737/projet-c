typedef struct 
{
int jour;
int mois;
int annee;
}Date;
typedef struct
{
char nom_voi[10];
char ville[50];
Date dt_res;
float prix;
int hr_res;
int hr_retour;
}reservationvoiture;
typedef struct 
{

char id[20];
}client;




int verifier_reserver_voiture(reservationvoiture voi);
int tableau_voiture_disponible(char voiture[100][50],
char ville[50],Date dt_res,int hr_res);
void reserver_voiture(reservationvoiture vo ,client c);
float calculer_prix_voiture(char voiture[50],char ville[50]);
